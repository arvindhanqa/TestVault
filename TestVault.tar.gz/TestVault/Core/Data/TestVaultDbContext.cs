using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Serilog;
using TestVault.Core.Models;
using TestVault.Core.Security;

namespace TestVault.Core.Data;

/// <summary>
/// SQLite database encrypted with SQLCipher (AES-256-CBC).
/// The encryption key is generated once and stored via DPAPI.
/// Even if someone copies the .db file, it's unreadable without
/// the current Windows user's credentials.
/// </summary>
public class TestVaultDbContext : DbContext
{
    private const string DbKeyName = "db_encryption_key";
    private static readonly string DbDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "TestVault", "data");
    private static readonly string DbPath = Path.Combine(DbDir, "testvault.db");

    public DbSet<TestCase> TestCases => Set<TestCase>();
    public DbSet<TestRun> TestRuns => Set<TestRun>();
    public DbSet<TestExecution> TestExecutions => Set<TestExecution>();
    public DbSet<ExcelSource> ExcelSources => Set<ExcelSource>();
    public DbSet<AuditEntry> AuditLog => Set<AuditEntry>();
    public DbSet<SyncMetadata> SyncMetadata => Set<SyncMetadata>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        Directory.CreateDirectory(DbDir);
        var dbKey = GetOrCreateDbKey();

        // SQLCipher connection string with encryption key
        var connectionString = $"Data Source={DbPath};Password={dbKey}";

        options.UseSqlite(connectionString, sqliteOptions =>
        {
            // Additional SQLCipher pragmas for maximum security
        });

        // Never log SQL statements containing data
        options.EnableSensitiveDataLogging(false);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // === Test Cases ===
        modelBuilder.Entity<TestCase>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Module);
            entity.HasIndex(e => e.Priority);
            entity.HasIndex(e => e.Status);
            entity.Property(e => e.Title).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Module).HasMaxLength(200);
        });

        // === Test Runs ===
        modelBuilder.Entity<TestRun>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
        });

        // === Test Executions ===
        modelBuilder.Entity<TestExecution>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasOne<TestCase>().WithMany().HasForeignKey(e => e.TestCaseId);
            entity.HasOne<TestRun>().WithMany().HasForeignKey(e => e.TestRunId);
        });

        // === Excel Source Tracking ===
        modelBuilder.Entity<ExcelSource>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FileHash).HasMaxLength(64); // SHA-256
            entity.Property(e => e.SharePointPath).HasMaxLength(1000);
        });

        // === Audit Log ===
        modelBuilder.Entity<AuditEntry>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Timestamp);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(100);
        });

        // === Sync Metadata ===
        modelBuilder.Entity<SyncMetadata>(entity =>
        {
            entity.HasKey(e => e.Id);
        });
    }

    /// <summary>
    /// Get existing or generate new AES-256 database encryption key.
    /// Key is stored encrypted via DPAPI — never in plaintext.
    /// </summary>
    private static string GetOrCreateDbKey()
    {
        using var secretStore = new SecretStore();
        var existingKey = secretStore.RetrieveSecret(DbKeyName);

        if (existingKey != null)
            return existingKey;

        // Generate a cryptographically random 256-bit key
        var keyBytes = new byte[32];
        RandomNumberGenerator.Fill(keyBytes);
        var newKey = Convert.ToBase64String(keyBytes);
        CryptographicOperations.ZeroMemory(keyBytes);

        secretStore.StoreSecret(DbKeyName, newKey);
        Log.Information("Generated new database encryption key");

        return newKey;
    }

    /// <summary>
    /// Verify database integrity on startup.
    /// Detects tampering or corruption.
    /// </summary>
    public async Task<bool> VerifyIntegrityAsync()
    {
        try
        {
            var result = await Database.ExecuteSqlRawAsync("PRAGMA integrity_check;");
            Log.Information("Database integrity check passed");
            return true;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Database integrity check FAILED — possible tampering");
            return false;
        }
    }

    /// <summary>
    /// Record an action in the immutable audit log.
    /// </summary>
    public async Task AuditAsync(string action, string? details = null)
    {
        AuditLog.Add(new AuditEntry
        {
            Action = action,
            Details = SanitizeForLog(details),
            Timestamp = DateTime.UtcNow,
            WindowsUser = Environment.UserName
        });
        await SaveChangesAsync();
    }

    /// <summary>
    /// Strip any potentially sensitive data from log entries.
    /// </summary>
    private static string? SanitizeForLog(string? input)
    {
        if (input == null) return null;

        // Remove anything that looks like a token, cookie, or password
        var sanitized = System.Text.RegularExpressions.Regex.Replace(
            input,
            @"(password|token|cookie|secret|key|authorization|bearer)\s*[:=]\s*\S+",
            "$1=***REDACTED***",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        return sanitized;
    }
}
