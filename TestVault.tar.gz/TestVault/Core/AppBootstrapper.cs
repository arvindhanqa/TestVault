using Serilog;
using TestVault.Core.Data;
using TestVault.Core.Security;
using TestVault.Core.SharePoint;

namespace TestVault.Core;

/// <summary>
/// Orchestrates the full secure startup and shutdown sequence.
/// 
/// Startup order matters for security:
/// 1. Initialize logger (with PII scrubbing)
/// 2. Run integrity checks
/// 3. Initialize network guard (blocks non-whitelisted connections)
/// 4. Initialize secret store (DPAPI)
/// 5. Initialize encrypted database
/// 6. Create secure temp directory
/// 7. Attempt session restore
/// 
/// Shutdown:
/// 1. Flush audit log
/// 2. Wipe secure temp directory
/// 3. Zero sensitive memory
/// 4. Flush and close logger
/// </summary>
public sealed class AppBootstrapper : IDisposable
{
    private SecretStore? _secretStore;
    private SecureTempDirectory? _tempDir;
    private TestVaultDbContext? _dbContext;
    private SecureSharePointClient? _sharePointClient;
    private bool _disposed;

    /// <summary>
    /// Application configuration loaded from local settings.
    /// </summary>
    public required AppConfig Config { get; init; }

    public SecretStore SecretStore => _secretStore ?? throw new InvalidOperationException("Not initialized");
    public SecureTempDirectory TempDir => _tempDir ?? throw new InvalidOperationException("Not initialized");
    public TestVaultDbContext Database => _dbContext ?? throw new InvalidOperationException("Not initialized");
    public SecureSharePointClient SharePoint => _sharePointClient ?? throw new InvalidOperationException("Not initialized");

    /// <summary>
    /// Run the full secure startup sequence.
    /// </summary>
    public async Task<StartupResult> InitializeAsync()
    {
        var result = new StartupResult();

        try
        {
            // 1. Logger first — everything else needs logging
            SecureLogger.Initialize();
            Log.Information("=== TestVault Starting ===");

            // 2. Integrity checks
            var integrity = await IntegrityChecker.RunAllChecksAsync();
            result.IntegrityPassed = integrity.AllPassed;

            if (!integrity.AllPassed)
            {
                Log.Error("Integrity checks failed. Proceeding with warnings.");
                // Don't hard-fail, but show warning to user
            }

            // 3. Network guard — BEFORE any network calls
            NetworkGuard.Initialize(new Uri(Config.SharePointSiteUrl).Host);

            // 4. Secret store
            _secretStore = new SecretStore();

            // 5. Encrypted database
            _dbContext = new TestVaultDbContext();
            await _dbContext.Database.EnsureCreatedAsync();
            result.DatabaseReady = await _dbContext.VerifyIntegrityAsync();

            // 6. Secure temp directory
            _tempDir = new SecureTempDirectory();

            // 7. SharePoint client
            _sharePointClient = new SecureSharePointClient(
                Config.SharePointSiteUrl, _secretStore, _tempDir);

            // 8. Try to restore previous session
            result.SessionRestored = await _sharePointClient.TryRestoreSessionAsync();

            // Audit the startup
            await _dbContext.AuditAsync("APP_START", $"Integrity: {integrity.AllPassed}, Session: {result.SessionRestored}");

            result.Success = true;
            Log.Information("=== TestVault Ready ===");
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Startup failed");
            result.Error = ex.Message;
        }

        return result;
    }

    /// <summary>
    /// Graceful shutdown — ensure all sensitive data is cleaned up.
    /// </summary>
    public async Task ShutdownAsync()
    {
        Log.Information("=== TestVault Shutting Down ===");

        try
        {
            // Audit the shutdown
            if (_dbContext != null)
                await _dbContext.AuditAsync("APP_SHUTDOWN");
        }
        catch { /* Don't fail shutdown for audit */ }

        Dispose();

        // Final log flush
        await Log.CloseAndFlushAsync();
    }

    /// <summary>
    /// Emergency purge — wipe ALL local data (panic button).
    /// </summary>
    public async Task EmergencyPurgeAsync()
    {
        Log.Warning("!!! EMERGENCY PURGE INITIATED !!!");

        try
        {
            // 1. Wipe temp files
            _tempDir?.Dispose();

            // 2. Wipe all secrets (including DB key — renders DB unreadable)
            _secretStore?.PurgeAll();

            // 3. Delete the database file
            var dbPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TestVault", "data", "testvault.db");
            SecretStore.SecureFileDelete(dbPath);

            // 4. Wipe logs
            var logDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TestVault", "logs");
            if (Directory.Exists(logDir))
            {
                foreach (var file in Directory.GetFiles(logDir))
                    SecretStore.SecureFileDelete(file);
            }

            Log.Warning("Emergency purge complete — all local data destroyed");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Error during emergency purge");
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        _sharePointClient?.Dispose();
        _tempDir?.Dispose();     // Wipes temp files
        _dbContext?.Dispose();
        _secretStore?.Dispose();
    }
}

public class StartupResult
{
    public bool Success { get; set; }
    public bool IntegrityPassed { get; set; }
    public bool DatabaseReady { get; set; }
    public bool SessionRestored { get; set; }
    public string? Error { get; set; }
}

/// <summary>
/// Application configuration — stored as encrypted JSON via DPAPI.
/// No plaintext config files.
/// </summary>
public class AppConfig
{
    public required string SharePointSiteUrl { get; set; }
    public string? DocumentLibraryName { get; set; }
    public int SyncIntervalMinutes { get; set; } = 30;
    public int MaxFileSizeMb { get; set; } = 100;
    public bool AutoSyncEnabled { get; set; } = true;

    private const string ConfigKey = "app_config";

    public static AppConfig LoadOrCreate(SecretStore store)
    {
        var json = store.RetrieveSecret(ConfigKey);
        if (json != null)
        {
            return System.Text.Json.JsonSerializer.Deserialize<AppConfig>(json)
                   ?? CreateDefault();
        }
        return CreateDefault();
    }

    public void Save(SecretStore store)
    {
        var json = System.Text.Json.JsonSerializer.Serialize(this);
        store.StoreSecret(ConfigKey, json);
    }

    private static AppConfig CreateDefault() => new()
    {
        SharePointSiteUrl = "https://yourcompany.sharepoint.com/sites/qa"
    };
}
