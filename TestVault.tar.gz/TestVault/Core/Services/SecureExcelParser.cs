using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using Serilog;
using TestVault.Core.Data;
using TestVault.Core.Models;
using TestVault.Core.Security;

namespace TestVault.Core.Services;

/// <summary>
/// Parses Excel files into the encrypted database.
///
/// Security:
/// - Files are parsed in-memory (never extracted to plaintext on disk)
/// - Input validation on all cell values (prevents injection)
/// - File hash tracking to detect unauthorized modifications
/// - Cell content length limits (prevents memory exhaustion)
/// </summary>
public class SecureExcelParser
{
    private readonly TestVaultDbContext _db;
    private const int MaxCellLength = 10_000;  // Prevent huge cell values
    private const int MaxRowsPerFile = 50_000;  // Sanity limit

    public event Action<string>? OnProgress;

    public SecureExcelParser(TestVaultDbContext db)
    {
        _db = db;
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
    }

    /// <summary>
    /// Parse an Excel file and upsert test cases into the encrypted DB.
    /// </summary>
    public async Task<ParseResult> ParseAndImportAsync(
        string filePath, string sharePointPath, string fileHash)
    {
        var result = new ParseResult { FileName = Path.GetFileName(filePath) };

        try
        {
            // Verify file hash hasn't changed since download (detect TOCTOU attack)
            var currentHash = await ComputeHashAsync(filePath);
            if (currentHash != fileHash)
            {
                Log.Error("File hash mismatch for {File}: expected {Expected}, got {Actual}",
                    result.FileName, fileHash[..16], currentHash[..16]);
                result.Error = "File integrity check failed — file may have been tampered with";
                return result;
            }

            await using var stream = File.OpenRead(filePath);
            using var package = new ExcelPackage(stream);

            // Track this source
            var source = await GetOrCreateSourceAsync(result.FileName, sharePointPath, fileHash, stream.Length);

            foreach (var worksheet in package.Workbook.Worksheets)
            {
                OnProgress?.Invoke($"Parsing: {result.FileName} / {worksheet.Name}");

                var parseResult = await ParseWorksheetAsync(worksheet, source);
                result.TestCasesParsed += parseResult.parsed;
                result.TestCasesUpdated += parseResult.updated;
                result.RowsSkipped += parseResult.skipped;
            }

            source.TotalTestCases = result.TestCasesParsed;
            source.LastSyncedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync();

            // Audit the import
            await _db.AuditAsync("EXCEL_IMPORT",
                $"File: {result.FileName}, Parsed: {result.TestCasesParsed}, Updated: {result.TestCasesUpdated}");

            result.Success = true;
            Log.Information("Parsed {File}: {Parsed} test cases, {Updated} updated",
                result.FileName, result.TestCasesParsed, result.TestCasesUpdated);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Failed to parse {File}", result.FileName);
            result.Error = ex.Message;
        }

        return result;
    }

    private async Task<(int parsed, int updated, int skipped)> ParseWorksheetAsync(
        ExcelWorksheet worksheet, ExcelSource source)
    {
        int parsed = 0, updated = 0, skipped = 0;

        if (worksheet.Dimension == null) return (0, 0, 0);

        var rowCount = Math.Min(worksheet.Dimension.End.Row, MaxRowsPerFile);
        var colCount = worksheet.Dimension.End.Column;

        // Auto-detect column mapping from header row
        var columnMap = DetectColumns(worksheet, colCount);

        if (columnMap.TitleColumn < 0)
        {
            Log.Warning("No title column found in worksheet {Name}", worksheet.Name);
            return (0, 0, rowCount - 1);
        }

        for (int row = 2; row <= rowCount; row++) // Skip header
        {
            var title = SafeGetCellValue(worksheet, row, columnMap.TitleColumn);

            if (string.IsNullOrWhiteSpace(title))
            {
                skipped++;
                continue;
            }

            // Check for existing test case (upsert logic)
            var existing = await _db.TestCases.FirstOrDefaultAsync(
                tc => tc.ExcelSourceId == source.Id && tc.ExcelRowNumber == row);

            if (existing != null)
            {
                // Update existing
                MapRowToTestCase(existing, worksheet, row, columnMap, source);
                existing.LastSyncedAt = DateTime.UtcNow;
                updated++;
            }
            else
            {
                // Create new
                var testCase = new TestCase
                {
                    Title = title,
                    ExcelSourceId = source.Id,
                    ExcelRowNumber = row,
                    ImportedAt = DateTime.UtcNow,
                    LastSyncedAt = DateTime.UtcNow
                };
                MapRowToTestCase(testCase, worksheet, row, columnMap, source);
                _db.TestCases.Add(testCase);
                parsed++;
            }

            // Batch save every 100 rows to avoid memory pressure
            if ((parsed + updated) % 100 == 0)
                await _db.SaveChangesAsync();
        }

        await _db.SaveChangesAsync();
        return (parsed, updated, skipped);
    }

    /// <summary>
    /// Auto-detect column positions by examining header row.
    /// Supports common test case column names.
    /// </summary>
    private static ColumnMap DetectColumns(ExcelWorksheet ws, int colCount)
    {
        var map = new ColumnMap();

        for (int col = 1; col <= colCount; col++)
        {
            var header = ws.Cells[1, col].Text?.Trim().ToLowerInvariant() ?? "";

            if (header.Contains("title") || header.Contains("test case") || header.Contains("name") || header.Contains("summary"))
                map.TitleColumn = col;
            else if (header.Contains("description") || header.Contains("detail"))
                map.DescriptionColumn = col;
            else if (header.Contains("module") || header.Contains("area") || header.Contains("component") || header.Contains("feature"))
                map.ModuleColumn = col;
            else if (header.Contains("priority") || header.Contains("severity"))
                map.PriorityColumn = col;
            else if (header.Contains("status") || header.Contains("state"))
                map.StatusColumn = col;
            else if (header.Contains("precondition") || header.Contains("pre-condition") || header.Contains("setup"))
                map.PreconditionsColumn = col;
            else if (header.Contains("step") || header.Contains("action") || header.Contains("procedure"))
                map.StepsColumn = col;
            else if (header.Contains("expected") || header.Contains("result"))
                map.ExpectedResultColumn = col;
            else if (header.Contains("assign") || header.Contains("owner") || header.Contains("tester"))
                map.AssigneeColumn = col;
            else if (header.Contains("tag") || header.Contains("label"))
                map.TagsColumn = col;
            else if (header.Contains("requirement") || header.Contains("req") || header.Contains("story") || header.Contains("ticket"))
                map.RequirementColumn = col;
        }

        return map;
    }

    private static void MapRowToTestCase(TestCase tc, ExcelWorksheet ws, int row, ColumnMap map, ExcelSource source)
    {
        tc.Title = SafeGetCellValue(ws, row, map.TitleColumn) ?? tc.Title;
        tc.Description = SafeGetCellValue(ws, row, map.DescriptionColumn);
        tc.Module = SafeGetCellValue(ws, row, map.ModuleColumn);
        tc.Priority = SafeGetCellValue(ws, row, map.PriorityColumn);
        tc.Status = SafeGetCellValue(ws, row, map.StatusColumn);
        tc.Preconditions = SafeGetCellValue(ws, row, map.PreconditionsColumn);
        tc.Steps = SafeGetCellValue(ws, row, map.StepsColumn);
        tc.ExpectedResult = SafeGetCellValue(ws, row, map.ExpectedResultColumn);
        tc.Assignee = SafeGetCellValue(ws, row, map.AssigneeColumn);
        tc.Tags = SafeGetCellValue(ws, row, map.TagsColumn);
        tc.RequirementId = SafeGetCellValue(ws, row, map.RequirementColumn);
        tc.FileHash = source.FileHash;
    }

    /// <summary>
    /// Safely extract cell value with input validation.
    /// Prevents injection and memory exhaustion.
    /// </summary>
    private static string? SafeGetCellValue(ExcelWorksheet ws, int row, int col)
    {
        if (col < 0) return null;

        var value = ws.Cells[row, col].Text?.Trim();

        if (string.IsNullOrEmpty(value))
            return null;

        // Truncate oversized values
        if (value.Length > MaxCellLength)
        {
            Log.Warning("Cell [{Row},{Col}] truncated from {Length} to {Max}",
                row, col, value.Length, MaxCellLength);
            value = value[..MaxCellLength];
        }

        // Strip any control characters (prevents terminal injection in logs/UI)
        value = new string(value.Where(c => !char.IsControl(c) || c == '\n' || c == '\r' || c == '\t').ToArray());

        return value;
    }

    private async Task<ExcelSource> GetOrCreateSourceAsync(
        string fileName, string sharePointPath, string fileHash, long fileSize)
    {
        var existing = await _db.ExcelSources
            .FirstOrDefaultAsync(s => s.SharePointPath == sharePointPath);

        if (existing != null)
        {
            existing.FileHash = fileHash;
            existing.FileSize = fileSize;
            existing.LastSyncedAt = DateTime.UtcNow;
            return existing;
        }

        var source = new ExcelSource
        {
            FileName = fileName,
            SharePointPath = sharePointPath,
            FileHash = fileHash,
            FileSize = fileSize,
            LastSyncedAt = DateTime.UtcNow,
            LastModifiedOnServer = DateTime.UtcNow
        };

        _db.ExcelSources.Add(source);
        await _db.SaveChangesAsync();
        return source;
    }

    private static async Task<string> ComputeHashAsync(string filePath)
    {
        await using var stream = File.OpenRead(filePath);
        var hash = await SHA256.HashDataAsync(stream);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}

internal class ColumnMap
{
    public int TitleColumn { get; set; } = -1;
    public int DescriptionColumn { get; set; } = -1;
    public int ModuleColumn { get; set; } = -1;
    public int PriorityColumn { get; set; } = -1;
    public int StatusColumn { get; set; } = -1;
    public int PreconditionsColumn { get; set; } = -1;
    public int StepsColumn { get; set; } = -1;
    public int ExpectedResultColumn { get; set; } = -1;
    public int AssigneeColumn { get; set; } = -1;
    public int TagsColumn { get; set; } = -1;
    public int RequirementColumn { get; set; } = -1;
}

public class ParseResult
{
    public string FileName { get; set; } = "";
    public bool Success { get; set; }
    public int TestCasesParsed { get; set; }
    public int TestCasesUpdated { get; set; }
    public int RowsSkipped { get; set; }
    public string? Error { get; set; }
}
