namespace TestVault.Core.Models;

public class TestCase
{
    public int Id { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
    public string? Module { get; set; }
    public string? Priority { get; set; }  // P1, P2, P3, P4
    public string? Status { get; set; }    // Active, Draft, Deprecated
    public string? Preconditions { get; set; }
    public string? Steps { get; set; }
    public string? ExpectedResult { get; set; }
    public string? Assignee { get; set; }
    public string? Tags { get; set; }
    public string? RequirementId { get; set; }  // Traceability
    public int ExcelSourceId { get; set; }
    public int ExcelRowNumber { get; set; }
    public DateTime ImportedAt { get; set; }
    public DateTime LastSyncedAt { get; set; }
    public string? FileHash { get; set; }  // Detect changes
}

public class TestRun
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public string? Environment { get; set; }  // QA, Staging, Prod
    public string? BuildVersion { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string? CreatedBy { get; set; }
}

public class TestExecution
{
    public int Id { get; set; }
    public int TestCaseId { get; set; }
    public int TestRunId { get; set; }
    public required string Result { get; set; }  // Pass, Fail, Blocked, Skipped
    public string? Notes { get; set; }
    public string? DefectId { get; set; }
    public DateTime ExecutedAt { get; set; }
    public string? ExecutedBy { get; set; }
    public int DurationSeconds { get; set; }
}

public class ExcelSource
{
    public int Id { get; set; }
    public required string FileName { get; set; }
    public required string SharePointPath { get; set; }
    public required string FileHash { get; set; }
    public long FileSize { get; set; }
    public DateTime LastModifiedOnServer { get; set; }
    public DateTime LastSyncedAt { get; set; }
    public int TotalTestCases { get; set; }
}

public class AuditEntry
{
    public int Id { get; set; }
    public required string Action { get; set; }
    public string? Details { get; set; }
    public DateTime Timestamp { get; set; }
    public required string WindowsUser { get; set; }
}

public class SyncMetadata
{
    public int Id { get; set; }
    public DateTime LastFullSync { get; set; }
    public DateTime LastIncrementalSync { get; set; }
    public int FilesTracked { get; set; }
    public int TotalTestCases { get; set; }
}
