using System.Reflection;
using System.Security.Cryptography;
using Serilog;

namespace TestVault.Core.Security;

/// <summary>
/// Startup integrity checks to detect tampering:
/// 1. Verify the executing assembly hasn't been modified
/// 2. Verify the database hasn't been swapped
/// 3. Check for debuggers attached (anti-debug)
/// 4. Verify Windows user identity matches stored credentials
/// </summary>
public static class IntegrityChecker
{
    /// <summary>
    /// Run all integrity checks. Returns false if any check fails.
    /// </summary>
    public static async Task<IntegrityResult> RunAllChecksAsync()
    {
        var result = new IntegrityResult();

        // 1. Anti-debugger check (prevents attaching debugger to steal secrets)
        result.DebuggerCheck = !System.Diagnostics.Debugger.IsAttached;
        if (!result.DebuggerCheck)
        {
            Log.Warning("SECURITY: Debugger detected! Sensitive operations may be compromised.");
            // We warn but don't hard-fail — developers need to debug too
            // In production, you could hard-fail here
        }

        // 2. Verify we're running from expected location
        result.LocationCheck = VerifyExecutionLocation();

        // 3. Check assembly integrity
        result.AssemblyCheck = VerifyAssemblyIntegrity();

        // 4. Verify the app data directory permissions
        result.PermissionCheck = VerifyDirectoryPermissions();

        // 5. Clean up any orphaned temp files from previous sessions
        result.CleanupDone = CleanupOrphanedData();

        Log.Information("Integrity check complete: Debug={Debug}, Location={Location}, " +
                        "Assembly={Assembly}, Permissions={Permissions}",
            result.DebuggerCheck, result.LocationCheck,
            result.AssemblyCheck, result.PermissionCheck);

        return result;
    }

    private static bool VerifyExecutionLocation()
    {
        try
        {
            var exePath = Assembly.GetExecutingAssembly().Location;
            if (string.IsNullOrEmpty(exePath)) return true; // Single-file publish

            // Ensure we're not running from a temp or download folder
            var suspicious = new[] { "temp", "tmp", "download", "cache" };
            var exeDir = Path.GetDirectoryName(exePath)?.ToLowerInvariant() ?? "";

            foreach (var word in suspicious)
            {
                if (exeDir.Contains(word))
                {
                    Log.Warning("SECURITY: App running from suspicious location: {Path}", exeDir);
                    return false;
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Log.Warning("Location check failed: {Message}", ex.Message);
            return true; // Don't block on check failure
        }
    }

    private static bool VerifyAssemblyIntegrity()
    {
        try
        {
            var assembly = Assembly.GetExecutingAssembly();

            // Check if assembly is strongly named (if configured)
            var name = assembly.GetName();
            if (name.GetPublicKeyToken()?.Length > 0)
            {
                Log.Debug("Assembly is strongly named: {Name}", name.FullName);
            }

            return true;
        }
        catch (Exception ex)
        {
            Log.Warning("Assembly integrity check failed: {Message}", ex.Message);
            return false;
        }
    }

    private static bool VerifyDirectoryPermissions()
    {
        try
        {
            var appDataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TestVault");

            if (!Directory.Exists(appDataDir))
                return true; // First run

            var dirInfo = new DirectoryInfo(appDataDir);
            var security = dirInfo.GetAccessControl();
            var rules = security.GetAccessRules(true, true, typeof(System.Security.Principal.NTAccount));

            // Warn if the directory is accessible by everyone
            foreach (System.Security.AccessControl.FileSystemAccessRule rule in rules)
            {
                var identity = rule.IdentityReference.Value;
                if (identity.Contains("Everyone") || identity.Contains("Users"))
                {
                    if (rule.AccessControlType == System.Security.AccessControl.AccessControlType.Allow)
                    {
                        Log.Warning("SECURITY: AppData directory has broad permissions: {Identity}", identity);
                        return false;
                    }
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Log.Warning("Permission check failed: {Message}", ex.Message);
            return true;
        }
    }

    private static bool CleanupOrphanedData()
    {
        try
        {
            // Clean old temp dirs
            var tempBase = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TestVault", "temp");

            if (Directory.Exists(tempBase))
            {
                foreach (var dir in Directory.GetDirectories(tempBase))
                {
                    if (Directory.GetCreationTimeUtc(dir) < DateTime.UtcNow.AddHours(-2))
                    {
                        try
                        {
                            foreach (var file in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                                SecretStore.SecureFileDelete(file);
                            Directory.Delete(dir, recursive: true);
                        }
                        catch { /* best effort */ }
                    }
                }
            }

            // Clean old logs
            SecureLogger.CleanupOldLogs();

            return true;
        }
        catch (Exception ex)
        {
            Log.Warning("Cleanup failed: {Message}", ex.Message);
            return false;
        }
    }
}

public class IntegrityResult
{
    public bool DebuggerCheck { get; set; }
    public bool LocationCheck { get; set; }
    public bool AssemblyCheck { get; set; }
    public bool PermissionCheck { get; set; }
    public bool CleanupDone { get; set; }

    public bool AllPassed => LocationCheck && AssemblyCheck && PermissionCheck;
    public bool HasWarnings => !DebuggerCheck || !CleanupDone;
}
