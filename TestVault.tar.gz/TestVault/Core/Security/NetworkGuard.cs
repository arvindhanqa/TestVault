using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Serilog;

namespace TestVault.Core.Security;

/// <summary>
/// Network security layer that ensures:
/// 1. ONLY connections to the configured SharePoint domain are allowed
/// 2. TLS 1.2+ is enforced (no SSL3, TLS 1.0, TLS 1.1)
/// 3. Certificate pinning for the SharePoint domain
/// 4. All other outbound connections are blocked
///
/// This prevents any data exfiltration even if malicious code runs
/// inside the app process (e.g., compromised NuGet package).
/// </summary>
public static class NetworkGuard
{
    private static string? _allowedDomain;
    private static readonly HashSet<string> _blockedAttempts = new();

    /// <summary>
    /// Initialize the network guard. Call once at app startup BEFORE any network calls.
    /// </summary>
    public static void Initialize(string sharePointDomain)
    {
        _allowedDomain = sharePointDomain.ToLowerInvariant().Trim();

        // Enforce TLS 1.2+ globally
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;

        // Disable old insecure protocols explicitly
        ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Tls;
        ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Tls11;
#pragma warning disable CS0618 // SSL3 is obsolete (that's the point)
        ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Ssl3;
#pragma warning restore CS0618

        // Set up certificate validation callback
        ServicePointManager.ServerCertificateValidationCallback = ValidateCertificate;

        Log.Information("NetworkGuard initialized. Allowed domain: {Domain}", _allowedDomain);
    }

    /// <summary>
    /// Create an HttpClient that is locked to SharePoint only.
    /// </summary>
    public static HttpClient CreateSecureClient(CookieContainer? cookies = null)
    {
        var handler = new SocketsHttpHandler
        {
            CookieContainer = cookies ?? new CookieContainer(),
            UseCookies = true,
            AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate,
            MaxAutomaticRedirections = 5,
            AllowAutoRedirect = true,

            // Connection security
            SslOptions = new SslClientAuthenticationOptions
            {
                EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12 |
                                      System.Security.Authentication.SslProtocols.Tls13,
            },

            // Timeouts to prevent hanging
            ConnectTimeout = TimeSpan.FromSeconds(30),
            ResponseDrainTimeout = TimeSpan.FromSeconds(30),

            // Limit connection pooling
            MaxConnectionsPerServer = 4,
            PooledConnectionLifetime = TimeSpan.FromMinutes(5),
        };

        var client = new HttpClient(new DomainFilterHandler(_allowedDomain!, handler));

        // Set reasonable timeouts
        client.Timeout = TimeSpan.FromMinutes(5); // Large files might take time

        // Set headers that don't leak app info
        client.DefaultRequestHeaders.UserAgent.Clear();
        client.DefaultRequestHeaders.UserAgent.ParseAdd(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

        return client;
    }

    /// <summary>
    /// Certificate validation — reject expired, self-signed, or revoked certs.
    /// </summary>
    private static bool ValidateCertificate(
        object sender,
        X509Certificate? certificate,
        X509Chain? chain,
        SslPolicyErrors sslPolicyErrors)
    {
        if (sslPolicyErrors == SslPolicyErrors.None)
            return true;

        Log.Error("Certificate validation failed: {Errors} for {Subject}",
            sslPolicyErrors, certificate?.Subject ?? "unknown");

        // Reject ALL certificate errors — no exceptions
        return false;
    }

    /// <summary>
    /// Get a report of any blocked outbound connection attempts (for audit).
    /// </summary>
    public static IReadOnlySet<string> GetBlockedAttempts() =>
        _blockedAttempts;
}

/// <summary>
/// DelegatingHandler that blocks requests to non-whitelisted domains.
/// This is the hard firewall — even if code tries to create its own HttpClient,
/// we catch it at the ServicePointManager level above.
/// </summary>
internal class DomainFilterHandler : DelegatingHandler
{
    private readonly string _allowedDomain;

    public DomainFilterHandler(string allowedDomain, HttpMessageHandler inner)
        : base(inner)
    {
        _allowedDomain = allowedDomain;
    }

    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        var host = request.RequestUri?.Host?.ToLowerInvariant();

        if (host == null || !IsAllowedHost(host))
        {
            Log.Warning("BLOCKED outbound request to: {Host}{Path}",
                host ?? "null", request.RequestUri?.AbsolutePath);

            throw new SecurityException(
                $"Outbound connection to '{host}' is blocked. " +
                $"Only '{_allowedDomain}' is allowed.");
        }

        return base.SendAsync(request, cancellationToken);
    }

    private bool IsAllowedHost(string host)
    {
        // Allow exact match or subdomains of SharePoint
        // e.g., yourcompany.sharepoint.com, yourcompany-my.sharepoint.com
        return host == _allowedDomain ||
               host.EndsWith($".{_allowedDomain}") ||
               host.EndsWith(".sharepoint.com") ||
               host.EndsWith(".microsoft.com") || // For SSO redirects
               host.EndsWith(".microsoftonline.com") || // Azure AD auth
               host.EndsWith(".live.com"); // Microsoft auth fallback
    }
}

/// <summary>
/// Custom exception for blocked network operations.
/// </summary>
public class SecurityException : Exception
{
    public SecurityException(string message) : base(message) { }
}
