using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Serilog;

namespace TestVault.Core.Security;

/// <summary>
/// Manages all secrets using Windows DPAPI (Data Protection API).
/// Secrets are encrypted with the current Windows user's credentials —
/// only this user on this machine can decrypt them.
/// No master passwords, no key files, no plaintext anywhere.
/// </summary>
public sealed class SecretStore : IDisposable
{
    private static readonly string VaultDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "TestVault", "secrets");

    // Additional entropy to prevent cross-app DPAPI decryption
    private static readonly byte[] AdditionalEntropy =
        Encoding.UTF8.GetBytes("TestVault-v1-2025-entropy-salt");

    private bool _disposed;

    public SecretStore()
    {
        Directory.CreateDirectory(VaultDir);

        // Lock down the secrets directory — current user only
        var dirInfo = new DirectoryInfo(VaultDir);
        var security = dirInfo.GetAccessControl();
        security.SetAccessRuleProtection(isProtected: true, preserveInheritance: false);

        var currentUser = System.Security.Principal.WindowsIdentity.GetCurrent();
        security.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(
            currentUser.Name,
            System.Security.AccessControl.FileSystemRights.FullControl,
            System.Security.AccessControl.InheritanceFlags.ContainerInherit |
            System.Security.AccessControl.InheritanceFlags.ObjectInherit,
            System.Security.AccessControl.PropagationFlags.None,
            System.Security.AccessControl.AccessControlType.Allow));

        dirInfo.SetAccessControl(security);
    }

    /// <summary>
    /// Encrypt and store a secret. Only the current Windows user can retrieve it.
    /// </summary>
    public void StoreSecret(string key, string value)
    {
        ThrowIfDisposed();
        ValidateKey(key);

        var plainBytes = Encoding.UTF8.GetBytes(value);
        try
        {
            var encrypted = ProtectedData.Protect(
                plainBytes,
                AdditionalEntropy,
                DataProtectionScope.CurrentUser);

            var filePath = GetSecretPath(key);
            File.WriteAllBytes(filePath, encrypted);

            // Set file to current-user-only access
            var fileInfo = new FileInfo(filePath);
            var security = fileInfo.GetAccessControl();
            security.SetAccessRuleProtection(isProtected: true, preserveInheritance: false);
            var currentUser = System.Security.Principal.WindowsIdentity.GetCurrent();
            security.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(
                currentUser.Name,
                System.Security.AccessControl.FileSystemRights.FullControl,
                System.Security.AccessControl.AccessControlType.Allow));
            fileInfo.SetAccessControl(security);

            Log.Debug("Secret stored: {Key}", key); // Never log the value!
        }
        finally
        {
            // Zero out plaintext bytes immediately
            CryptographicOperations.ZeroMemory(plainBytes);
        }
    }

    /// <summary>
    /// Retrieve and decrypt a secret. Returns null if not found.
    /// </summary>
    public string? RetrieveSecret(string key)
    {
        ThrowIfDisposed();
        ValidateKey(key);

        var filePath = GetSecretPath(key);
        if (!File.Exists(filePath))
            return null;

        var encrypted = File.ReadAllBytes(filePath);
        byte[]? decrypted = null;
        try
        {
            decrypted = ProtectedData.Unprotect(
                encrypted,
                AdditionalEntropy,
                DataProtectionScope.CurrentUser);

            return Encoding.UTF8.GetString(decrypted);
        }
        catch (CryptographicException ex)
        {
            Log.Warning("Failed to decrypt secret {Key}: {Message}", key, ex.Message);
            return null;
        }
        finally
        {
            if (decrypted != null)
                CryptographicOperations.ZeroMemory(decrypted);
        }
    }

    /// <summary>
    /// Securely delete a secret — overwrite before deletion.
    /// </summary>
    public void DeleteSecret(string key)
    {
        ThrowIfDisposed();
        var filePath = GetSecretPath(key);
        SecureFileDelete(filePath);
    }

    /// <summary>
    /// Store cookies as an encrypted JSON blob.
    /// </summary>
    public void StoreCookies(string domain, IEnumerable<CookieData> cookies)
    {
        var json = JsonSerializer.Serialize(cookies);
        StoreSecret($"cookies_{SanitizeDomain(domain)}", json);
    }

    /// <summary>
    /// Retrieve stored cookies for a domain.
    /// </summary>
    public IEnumerable<CookieData>? RetrieveCookies(string domain)
    {
        var json = RetrieveSecret($"cookies_{SanitizeDomain(domain)}");
        if (json == null) return null;

        return JsonSerializer.Deserialize<IEnumerable<CookieData>>(json);
    }

    /// <summary>
    /// Overwrite file contents with random data before deleting.
    /// Prevents forensic recovery.
    /// </summary>
    public static void SecureFileDelete(string filePath)
    {
        if (!File.Exists(filePath)) return;

        var fileInfo = new FileInfo(filePath);
        var length = fileInfo.Length;

        // Three-pass overwrite: zeros, ones, random
        using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Write))
        {
            var buffer = new byte[4096];

            // Pass 1: zeros
            for (long i = 0; i < length; i += buffer.Length)
                stream.Write(buffer, 0, (int)Math.Min(buffer.Length, length - i));

            // Pass 2: ones
            stream.Seek(0, SeekOrigin.Begin);
            Array.Fill<byte>(buffer, 0xFF);
            for (long i = 0; i < length; i += buffer.Length)
                stream.Write(buffer, 0, (int)Math.Min(buffer.Length, length - i));

            // Pass 3: random
            stream.Seek(0, SeekOrigin.Begin);
            using var rng = RandomNumberGenerator.Create();
            for (long i = 0; i < length; i += buffer.Length)
            {
                rng.GetBytes(buffer);
                stream.Write(buffer, 0, (int)Math.Min(buffer.Length, length - i));
            }

            stream.Flush();
        }

        File.Delete(filePath);
        Log.Debug("Securely deleted: {Path}", filePath);
    }

    /// <summary>
    /// Wipe ALL secrets — used during uninstall or emergency purge.
    /// </summary>
    public void PurgeAll()
    {
        if (Directory.Exists(VaultDir))
        {
            foreach (var file in Directory.GetFiles(VaultDir))
                SecureFileDelete(file);
            Directory.Delete(VaultDir, recursive: true);
        }
        Log.Information("All secrets purged");
    }

    private static string GetSecretPath(string key) =>
        Path.Combine(VaultDir, $"{key}.vault");

    private static string SanitizeDomain(string domain) =>
        domain.Replace(".", "_").Replace(":", "_");

    private static void ValidateKey(string key)
    {
        if (string.IsNullOrWhiteSpace(key))
            throw new ArgumentException("Secret key cannot be empty");
        if (key.Any(c => Path.GetInvalidFileNameChars().Contains(c)))
            throw new ArgumentException("Secret key contains invalid characters");
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new ObjectDisposedException(nameof(SecretStore));
    }

    public void Dispose()
    {
        _disposed = true;
    }
}

/// <summary>
/// Serializable cookie representation — never stores raw Set-Cookie headers.
/// </summary>
public record CookieData(
    string Name,
    string Value,
    string Domain,
    string Path,
    DateTime Expires,
    bool IsSecure,
    bool IsHttpOnly);
