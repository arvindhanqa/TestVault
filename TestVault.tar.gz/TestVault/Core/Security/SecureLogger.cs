using System.Text.RegularExpressions;
using Serilog;
using Serilog.Core;
using Serilog.Events;

namespace TestVault.Core.Security;

/// <summary>
/// Configures a security-hardened logging pipeline:
/// - PII and secrets are automatically redacted
/// - Logs stored in user-local directory with restricted permissions
/// - Log rotation with secure deletion of old files
/// - No sensitive data ever reaches disk
/// </summary>
public static partial class SecureLogger
{
    private static readonly string LogDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "TestVault", "logs");

    public static void Initialize()
    {
        Directory.CreateDirectory(LogDir);

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .MinimumLevel.Override("Microsoft.EntityFrameworkCore", LogEventLevel.Warning)
            .Enrich.With<PiiScrubberEnricher>()
            .WriteTo.File(
                path: Path.Combine(LogDir, "testvault-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,   // Keep only 7 days
                fileSizeLimitBytes: 10_000_000, // 10MB max per file
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        Log.Information("TestVault started. Logging initialized.");
    }

    /// <summary>
    /// Securely delete old log files (overwrite before delete).
    /// </summary>
    public static void CleanupOldLogs(int daysToKeep = 7)
    {
        if (!Directory.Exists(LogDir)) return;

        var cutoff = DateTime.UtcNow.AddDays(-daysToKeep);
        foreach (var file in Directory.GetFiles(LogDir, "*.log"))
        {
            if (File.GetLastWriteTimeUtc(file) < cutoff)
            {
                SecretStore.SecureFileDelete(file);
            }
        }
    }
}

/// <summary>
/// Serilog enricher that scrubs PII and secrets from ALL log messages
/// before they're written to disk. Belt-and-suspenders approach.
/// </summary>
internal class PiiScrubberEnricher : ILogEventEnricher
{
    // Patterns that indicate sensitive data
    private static readonly Regex[] SensitivePatterns =
    [
        // Tokens and cookies
        new(@"(Bearer\s+)\S+", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new(@"(token|cookie|session[_-]?id)\s*[:=]\s*\S+", RegexOptions.IgnoreCase | RegexOptions.Compiled),

        // Auth headers
        new(@"(Authorization|Set-Cookie|Cookie)\s*:\s*.+", RegexOptions.IgnoreCase | RegexOptions.Compiled),

        // Passwords and keys
        new(@"(password|passwd|pwd|secret|key|apikey|api_key)\s*[:=]\s*\S+", RegexOptions.IgnoreCase | RegexOptions.Compiled),

        // Email addresses (could identify users)
        new(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", RegexOptions.Compiled),

        // Base64 strings longer than 40 chars (likely tokens)
        new(@"[A-Za-z0-9+/=]{40,}", RegexOptions.Compiled),

        // JWT tokens
        new(@"eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*", RegexOptions.Compiled),
    ];

    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        // We can't modify the message template directly, but we ensure
        // properties that contain sensitive data are scrubbed
        var scrubbed = new Dictionary<string, LogEventPropertyValue>();

        foreach (var prop in logEvent.Properties)
        {
            if (prop.Value is ScalarValue scalar && scalar.Value is string strValue)
            {
                var clean = ScrubSensitiveData(strValue);
                if (clean != strValue)
                {
                    scrubbed[prop.Key] = new ScalarValue(clean);
                }
            }
        }

        foreach (var kvp in scrubbed)
        {
            logEvent.AddOrUpdateProperty(new LogEventProperty(kvp.Key, kvp.Value));
        }
    }

    private static string ScrubSensitiveData(string input)
    {
        var result = input;
        foreach (var pattern in SensitivePatterns)
        {
            result = pattern.Replace(result, "***REDACTED***");
        }
        return result;
    }
}
