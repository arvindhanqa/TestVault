using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace TestVault.Core.Security;

/// <summary>
/// Memory protection utilities to prevent sensitive data from
/// lingering in RAM where it could be extracted via memory dumps,
/// swap files, or debugging tools.
/// </summary>
public static class MemoryGuard
{
    /// <summary>
    /// Execute an action with a sensitive string that is automatically
    /// zeroed out after use. Prevents the string from being interned
    /// or kept in memory by the GC.
    /// </summary>
    public static T UseSecret<T>(byte[] secretBytes, Func<string, T> action)
    {
        // Pin the array so GC doesn't move it (leaving copies)
        var handle = GCHandle.Alloc(secretBytes, GCHandleType.Pinned);
        try
        {
            var secret = System.Text.Encoding.UTF8.GetString(secretBytes);
            return action(secret);
        }
        finally
        {
            // Zero the original bytes
            CryptographicOperations.ZeroMemory(secretBytes);
            handle.Free();
        }
    }

    /// <summary>
    /// Securely zero a byte array, defeating compiler optimizations
    /// that might skip the zeroing as "unnecessary".
    /// </summary>
    [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
    public static void SecureZero(byte[] data)
    {
        if (data == null) return;
        CryptographicOperations.ZeroMemory(data);
        // Volatile read to prevent dead-store elimination
        _ = Volatile.Read(ref data[0]);
    }

    /// <summary>
    /// Securely zero a char array (e.g., from password entry).
    /// </summary>
    [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
    public static void SecureZero(char[] data)
    {
        if (data == null) return;
        Array.Clear(data, 0, data.Length);
        _ = Volatile.Read(ref data[0]);
    }

    /// <summary>
    /// Create a pinned buffer for temporary sensitive operations.
    /// The buffer is automatically zeroed when disposed.
    /// </summary>
    public static PinnedBuffer CreatePinnedBuffer(int size)
    {
        return new PinnedBuffer(size);
    }
}

/// <summary>
/// A byte buffer pinned in memory that is guaranteed to be
/// zeroed and unpinned when disposed. Use for temporary crypto operations.
/// </summary>
public sealed class PinnedBuffer : IDisposable
{
    private readonly byte[] _buffer;
    private readonly GCHandle _handle;
    private bool _disposed;

    public PinnedBuffer(int size)
    {
        _buffer = new byte[size];
        _handle = GCHandle.Alloc(_buffer, GCHandleType.Pinned);
    }

    public byte[] Buffer
    {
        get
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            return _buffer;
        }
    }

    public Span<byte> Span => Buffer.AsSpan();
    public int Length => _buffer.Length;

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        CryptographicOperations.ZeroMemory(_buffer);
        _handle.Free();
    }
}
