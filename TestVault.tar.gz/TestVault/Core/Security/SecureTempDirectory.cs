using System.Security.Cryptography;
using Serilog;

namespace TestVault.Core.Security;

/// <summary>
/// Manages a private temp directory for staging downloaded Excel files.
/// 
/// Why not use System.IO.Path.GetTempPath()?
/// - OS temp is shared across all apps → other processes could read our files
/// - OS temp isn't cleaned reliably → files persist after app closes
/// - We can't control ACLs on the global temp dir
/// 
/// This creates an isolated, access-controlled directory that:
/// - Lives under our AppData folder with restricted permissions
/// - Auto-wipes ALL files when the app exits (normal or crash)
/// - Securely overwrites before deleting (3-pass wipe)
/// - Uses randomized subdirectory names per session
/// </summary>
public sealed class SecureTempDirectory : IDisposable
{
    private readonly string _sessionDir;
    private bool _disposed;

    private static readonly string BaseDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "TestVault", "temp");

    public SecureTempDirectory()
    {
        // Each session gets a random subdirectory
        var sessionId = Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
        _sessionDir = Path.Combine(BaseDir, sessionId);
        Directory.CreateDirectory(_sessionDir);

        // Restrict access to current user only
        var dirInfo = new DirectoryInfo(_sessionDir);
        var security = dirInfo.GetAccessControl();
        security.SetAccessRuleProtection(isProtected: true, preserveInheritance: false);
        var currentUser = System.Security.Principal.WindowsIdentity.GetCurrent();
        security.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(
            currentUser.Name,
            System.Security.AccessControl.FileSystemRights.FullControl,
            System.Security.AccessControl.InheritanceFlags.ContainerInherit |
            System.Security.AccessControl.InheritanceFlags.ObjectInherit,
            System.Security.AccessControl.PropagationFlags.None,
            System.Security.AccessControl.AccessControlType.Allow));
        dirInfo.SetAccessControl(security);

        // Register cleanup for unexpected exits
        AppDomain.CurrentDomain.ProcessExit += (_, _) => Cleanup();
        AppDomain.CurrentDomain.UnhandledException += (_, _) => Cleanup();

        Log.Debug("Secure temp dir created: {Dir}", _sessionDir);
    }

    /// <summary>
    /// Get a path for a temp file. The file doesn't exist yet.
    /// </summary>
    public string GetTempFilePath(string originalFileName)
    {
        ThrowIfDisposed();
        // Sanitize the file name
        var safeName = SanitizeFileName(originalFileName);
        return Path.Combine(_sessionDir, safeName);
    }

    /// <summary>
    /// Write data to a temp file and return the path.
    /// </summary>
    public async Task<string> WriteTempFileAsync(string originalFileName, byte[] data)
    {
        ThrowIfDisposed();
        var path = GetTempFilePath(originalFileName);
        await File.WriteAllBytesAsync(path, data);
        return path;
    }

    /// <summary>
    /// Write a stream to a temp file and return the path.
    /// </summary>
    public async Task<string> WriteTempFileAsync(string originalFileName, Stream stream)
    {
        ThrowIfDisposed();
        var path = GetTempFilePath(originalFileName);
        await using var fs = File.Create(path);
        await stream.CopyToAsync(fs);
        return path;
    }

    /// <summary>
    /// Compute SHA-256 hash of a file for integrity verification.
    /// </summary>
    public static async Task<string> ComputeFileHashAsync(string filePath)
    {
        await using var stream = File.OpenRead(filePath);
        var hash = await SHA256.HashDataAsync(stream);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    /// <summary>
    /// Securely delete a specific temp file.
    /// </summary>
    public void SecureDeleteFile(string filePath)
    {
        if (filePath.StartsWith(_sessionDir))
            SecretStore.SecureFileDelete(filePath);
    }

    /// <summary>
    /// Wipe the entire session temp directory.
    /// Called automatically on Dispose and app exit.
    /// </summary>
    private void Cleanup()
    {
        try
        {
            if (!Directory.Exists(_sessionDir)) return;

            foreach (var file in Directory.GetFiles(_sessionDir, "*", SearchOption.AllDirectories))
            {
                SecretStore.SecureFileDelete(file);
            }

            Directory.Delete(_sessionDir, recursive: true);
            Log.Debug("Secure temp dir wiped: {Dir}", _sessionDir);

            // Also clean up any orphaned session dirs from crashed sessions
            CleanupOrphanedDirs();
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "Error during temp dir cleanup");
        }
    }

    /// <summary>
    /// Remove any temp dirs from previous crashed sessions.
    /// </summary>
    private static void CleanupOrphanedDirs()
    {
        if (!Directory.Exists(BaseDir)) return;

        foreach (var dir in Directory.GetDirectories(BaseDir))
        {
            try
            {
                // If dir is older than 1 hour, it's orphaned
                if (Directory.GetCreationTimeUtc(dir) < DateTime.UtcNow.AddHours(-1))
                {
                    foreach (var file in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                        SecretStore.SecureFileDelete(file);
                    Directory.Delete(dir, recursive: true);
                    Log.Information("Cleaned orphaned temp dir: {Dir}", dir);
                }
            }
            catch { /* Best effort */ }
        }
    }

    private static string SanitizeFileName(string fileName)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var sanitized = new string(fileName.Select(c => invalid.Contains(c) ? '_' : c).ToArray());

        // Prevent path traversal
        sanitized = sanitized.Replace("..", "_");

        // Limit length
        if (sanitized.Length > 200)
            sanitized = sanitized[..200];

        return sanitized;
    }

    private void ThrowIfDisposed()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Cleanup();
    }
}
