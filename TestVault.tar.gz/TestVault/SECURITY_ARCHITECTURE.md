# TestVault — Security Architecture

## Threat Model

### What We Protect
- SharePoint session cookies (SSO tokens)
- Downloaded Excel files containing test case data
- SQLite database with parsed test data
- Audit logs
- Any credentials transiting through memory

### Attack Vectors Mitigated

| # | Threat | Mitigation |
|---|--------|------------|
| 1 | Database theft (laptop stolen) | SQLCipher AES-256 encryption with DPAPI-protected key |
| 2 | Cookie/token theft from disk | Windows DPAPI encryption, never written to plain text |
| 3 | Memory scraping | SecureString, explicit memory zeroing, GC pinning |
| 4 | Man-in-the-middle | Certificate pinning for SharePoint domain, TLS 1.2+ only |
| 5 | DLL injection / tampering | Assembly signing, integrity checks at startup |
| 6 | Temp file leaks | Secure temp directory with auto-wipe, no OS temp usage |
| 7 | Clipboard exfiltration | No auto-copy of sensitive data, clipboard clear on exit |
| 8 | Screen capture of sensitive data | Sensitive fields masked by default |
| 9 | Log file data leaks | Structured logging with PII scrubber, no cookie/token logging |
| 10 | Unauthorized access | Local Windows auth check, optional PIN lock |
| 11 | Telemetry/phone-home | Zero outbound connections except SharePoint, DNS verified |
| 12 | Residual data after uninstall | Secure wipe utility included |

## Data Flow

```
SharePoint (HTTPS only)
    │
    ▼
WebView2 (SSO login)
    │
    ▼ Cookies encrypted via DPAPI → Credential Store
    │
    ▼
HttpClient (cert-pinned, TLS 1.2+)
    │
    ▼ Downloads to encrypted temp dir
    │
    ▼
EPPlus Parser (in-memory only)
    │
    ▼
SQLCipher Database (AES-256-CBC, 256K iterations)
    │
    ▼
WPF Dashboard (local rendering only)
```

## Zero Trust Principles Applied
1. **No data at rest without encryption** — every file, every database, every cache
2. **No network except SharePoint** — outbound connections are whitelisted
3. **No trust in the OS temp directory** — we manage our own secure temp
4. **Principle of least privilege** — app requests minimum Windows permissions
5. **Defense in depth** — even if one layer fails, data remains protected
