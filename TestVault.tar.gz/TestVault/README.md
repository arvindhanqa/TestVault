# 🛡️ TestVault — Secure Local Test Management Tool

**Zero-trust, zero-cloud, zero-leaks** test case management that syncs from SharePoint.

## Why This Exists

Your company stores test cases in Excel on SharePoint but won't buy a test management tool. TestVault bridges that gap — it pulls your Excel files via your normal SSO login, stores everything in an encrypted local database, and gives you a real test management dashboard. No data ever leaves your machine.

---

## Security Posture

### Data at Rest
| Layer | Protection |
|-------|-----------|
| Database | SQLCipher AES-256-CBC (256K iterations) |
| DB encryption key | Windows DPAPI (tied to your Windows user account) |
| Session cookies | DPAPI-encrypted, never plaintext on disk |
| Temp files | Isolated directory, 3-pass secure wipe on exit |
| Config | DPAPI-encrypted JSON, no plaintext config files |
| Logs | PII auto-scrubbed, 7-day rotation with secure deletion |

### Data in Transit
| Layer | Protection |
|-------|-----------|
| TLS | 1.2+ enforced, SSL3/TLS1.0/1.1 disabled |
| Certificates | Validated — expired/self-signed/revoked rejected |
| Domain whitelist | Only *.sharepoint.com and Microsoft auth domains |
| Outbound firewall | All other domains blocked at handler level |

### Runtime Protection
| Layer | Protection |
|-------|-----------|
| Memory | Sensitive data pinned + zeroed after use |
| Anti-debug | Debugger detection with audit logging |
| Integrity | Assembly and directory permission checks at startup |
| Input validation | Cell content sanitized, length-limited, control chars stripped |
| File validation | SHA-256 hash verification, file type whitelist, size limits |
| Audit trail | Every action logged (immutable, in encrypted DB) |

### Emergency
| Feature | Description |
|---------|-------------|
| Panic Purge | One-click destroys all local data (DB, secrets, temp, logs) |
| Session expire | Auto-detects 401, forces re-authentication |
| Orphan cleanup | Crashed session temp files auto-wiped on next start |

---

## Architecture

```
TestVault/
├── Core/
│   ├── Security/
│   │   ├── SecretStore.cs          ← DPAPI secret management
│   │   ├── NetworkGuard.cs         ← Domain whitelist firewall
│   │   ├── MemoryGuard.cs          ← Sensitive data memory protection
│   │   ├── SecureTempDirectory.cs  ← Auto-wiping temp file staging
│   │   ├── SecureLogger.cs         ← PII-scrubbing audit logger
│   │   └── IntegrityChecker.cs     ← Startup tamper detection
│   ├── Data/
│   │   └── TestVaultDbContext.cs    ← SQLCipher encrypted database
│   ├── SharePoint/
│   │   └── SecureSharePointClient.cs ← WebView2 cookie harvesting + download
│   ├── Services/
│   │   └── SecureExcelParser.cs     ← In-memory Excel→DB parser
│   ├── Models/
│   │   └── Models.cs                ← Test case, run, execution entities
│   └── AppBootstrapper.cs           ← Secure startup/shutdown orchestration
├── UI/
│   ├── Views/                       ← WPF XAML views (TODO)
│   └── ViewModels/                  ← MVVM view models (TODO)
├── TestVault.csproj
├── SECURITY_ARCHITECTURE.md
└── README.md
```

---

## Quick Start

### Prerequisites
- Windows 10/11
- .NET 8 SDK
- WebView2 Runtime (pre-installed on Windows 11, or install from Microsoft)

### Build & Run
```powershell
# Clone and build
git clone <your-repo>
cd TestVault
dotnet restore
dotnet build -c Release

# Run
dotnet run
```

### First Launch
1. App opens WebView2 → SharePoint SSO login appears
2. Log in normally (Okta, Azure AD, whatever your company uses)
3. App captures your session cookies (encrypted via DPAPI)
4. Select your document library → Excel files sync
5. Dashboard appears with your test cases

### Subsequent Launches
- App tries to restore your previous session automatically
- If session expired → SSO login appears again
- All data persists in encrypted local database

---

## Configuration

On first run, the app creates encrypted config. You can modify via the Settings UI:

- **SharePoint Site URL** — `https://yourcompany.sharepoint.com/sites/qa`
- **Document Library** — Name of the library containing Excel files
- **Sync Interval** — How often to check for changes (default: 30 min)
- **Auto-sync** — Enable/disable background sync

---

## What DOESN'T Leave Your Machine

- ✅ Excel file contents → encrypted in local SQLite
- ✅ Session cookies → DPAPI encrypted
- ✅ Test execution results → local DB only
- ✅ Dashboard data → rendered locally in WPF
- ✅ Logs → local only, PII scrubbed
- ✅ Config → DPAPI encrypted, no cloud sync

## What DOES Leave Your Machine

- 🔒 HTTPS requests to your SharePoint (only when syncing)
- 🔒 SSO authentication flow (to Microsoft/your IdP)
- ❌ Nothing else. Zero telemetry. Zero analytics. Zero phone-home.

---

## Next Steps (UI Phase)

The security foundation is complete. Remaining work:

1. **WPF Shell** — MainWindow with WebView2 login panel + dashboard
2. **Test Case Browser** — DataGrid with filtering/grouping/search
3. **Dashboard** — LiveCharts2 visualizations (coverage, pass/fail, trends)
4. **Test Run Manager** — Create runs, execute tests, track results
5. **Export** — Generate reports back to Excel
6. **Column Mapping UI** — Let users configure which Excel columns map to which fields
